import os
import pandas as pd
import numpy as np
import tensorflow as tf
from sklearn.preprocessing import StandardScaler

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
os.chdir(os.path.dirname(os.path.abspath(__file__)))

def create_enhanced_features(df, holidays_df):
    df = df.copy()
    df['datetime'] = pd.to_datetime(df['datetime'])
    
    try:
        # Fix: use 'isntworkday' as holiday indicator
        holidays_df['DateKEY'] = pd.to_datetime(holidays_df['DateKEY'], format='%Y%m%d')
        holiday_dates = holidays_df[holidays_df['isntworkday'] == 1]['DateKEY'].dt.date
    except Exception as e:
        print(f"⚠️ Error parsing holidays_df['DateKEY'] or 'isntworkday': {e}")
        holiday_dates = pd.Series(dtype='object')

    # Validate date ranges
    data_dates = df['datetime'].dt.date
    if not holiday_dates.empty:
        print(f"📊 Data date range: {data_dates.min()} to {data_dates.max()}")
        print(f"📊 Holiday date range: {holiday_dates.min()} to {holiday_dates.max()}")
        common_dates = set(data_dates).intersection(set(holiday_dates))
        print(f"📊 Common dates count: {len(common_dates)} (expected ~10-20% of {len(data_dates)} rows)")
    else:
        common_dates = set()
        print("⚠️ Holiday file invalid or empty.")

    # Fallback if holiday data is invalid or over-saturated
    if len(common_dates) == 0 or len(common_dates) >= len(data_dates) * 0.5:
        print("⚠️ Warning: Invalid holiday data. Using fallback Finnish holidays (2017–2020).")
        holiday_dates = pd.to_datetime([
            '2017-01-01', '2017-01-06', '2017-04-14', '2017-04-17', '2017-05-01',
            '2017-05-25', '2017-06-24', '2017-11-04', '2017-12-06', '2017-12-25', '2017-12-26',
            '2018-01-01', '2018-01-06', '2018-03-30', '2018-04-02', '2018-05-01',
            '2018-05-10', '2018-06-23', '2018-11-03', '2018-12-06', '2018-12-25', '2018-12-26',
            '2019-01-01', '2019-01-06', '2019-04-19', '2019-04-22', '2019-05-01',
            '2019-05-30', '2019-06-22', '2019-11-02', '2019-12-06', '2019-12-25', '2019-12-26',
            '2020-01-01', '2020-01-06', '2020-04-10', '2020-04-13', '2020-05-01',
            '2020-05-21', '2020-06-20', '2020-10-31', '2020-12-06', '2020-12-25', '2020-12-26'
        ]).date

    # Feature engineering
    df['hour'] = df['datetime'].dt.hour
    df['weekday'] = df['datetime'].dt.weekday
    df['is_weekend'] = df['weekday'].isin([5, 6]).astype(int)
    df['is_holiday'] = df['datetime'].dt.date.isin(holiday_dates).astype(int)
    df['is_long_holiday'] = df['is_holiday'].rolling(window=7, min_periods=1).sum().fillna(0)
    df['avg_temperature'] = df['air_temperature'].rolling(window=7, min_periods=1).mean().ffill()
    df['temp_lag1'] = df['air_temperature'].shift(1).ffill()
    df['is_peak_hour'] = df['hour'].isin([8, 9, 17, 18]).astype(int)
    df.fillna(df.mean(numeric_only=True), inplace=True)

    # Validation
    holiday_ratio = df['is_holiday'].mean()
    print(f"📊 Features added: is_holiday_count={df['is_holiday'].sum()}, is_long_holiday_mean={df['is_long_holiday'].mean():.2f}")
    print(f"   is_holiday ratio: {holiday_ratio:.2%} (expected ~10-20%)")
    print(f"   Sample features:\n{df[['hour', 'weekday', 'is_holiday', 'is_peak_hour']].head(2)}")

    # Revalidate if holiday ratio too high
    if holiday_ratio > 0.5:
        print(f"⚠️ Error: is_holiday ratio too high ({holiday_ratio:.2%}). Using fallback holidays.")
        df['is_holiday'] = df['datetime'].dt.date.isin(holiday_dates).astype(int)
        df['is_long_holiday'] = df['is_holiday'].rolling(window=7, min_periods=1).sum().fillna(0)
        holiday_ratio = df['is_holiday'].mean()
        print(f"📊 Corrected: is_holiday_count={df['is_holiday'].sum()}, is_holiday ratio: {holiday_ratio:.2%}")

    return df

def standardize_features(df_train, df_val, df_test, selected_features):
    scaler = StandardScaler()
    df_train_scaled = pd.DataFrame(
        scaler.fit_transform(df_train[selected_features]),
        columns=selected_features,
        index=df_train.index
    )
    df_val_scaled = pd.DataFrame(
        scaler.transform(df_val[selected_features]),
        columns=selected_features,
        index=df_val.index
    )
    df_test_scaled = pd.DataFrame(
        scaler.transform(df_test[selected_features]),
        columns=selected_features,
        index=df_test.index
    )
    print(f"📊 Scaler stats: mean={scaler.mean_[:5]}, std={scaler.scale_[:5]}")
    return df_train_scaled, df_val_scaled, df_test_scaled, scaler

def create_sliding_windows(X_full, y_full, input_window, output_window):
    X, y = [], []
    for i in range(len(X_full) - input_window - output_window + 1):
        X.append(X_full[i:i + input_window])
        y.append(y_full[i + input_window:i + input_window + output_window].flatten())
    print(f"📊 Sliding windows: X_shape={np.array(X).shape}, y_shape={np.array(y).shape}")
    return np.array(X), np.array(y)

def create_tf_dataset(X, y, batch_size=32):
    dataset = tf.data.Dataset.from_tensor_slices((X, y))
    return dataset.shuffle(buffer_size=10000).batch(batch_size).prefetch(tf.data.AUTOTUNE)
