import os
import pandas as pd
from data_utils import create_enhanced_features, standardize_features

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'  # Suppress TensorFlow warnings
os.chdir(os.path.dirname(os.path.abspath(__file__)))

# Configuration
PARQUET_FILES = ["dataset_0.parquet", "dataset_1.parquet", "dataset_2.parquet"]
EXCEL_FILES = [
    "0_weather_data_testing_0.xlsx",
    "1_weather_data_validation_1.xlsx",
    "2_weather_data_training_2.xlsx"
]
HOLIDAY_FILE = "3.Holydays .xlsx"
SELECTED_FEATURES = [
    'air_temperature', 'diffuse_r', 'elspot', 'full_solar', 'global_r',
    'gust_speed', 'relative_humidity', 'sunshine', 'wind_speed',
    'hour', 'weekday', 'is_weekend', 'is_holiday', 'is_long_holiday',
    'avg_temperature', 'temp_lag1', 'is_peak_hour'
]

def load_and_save_excel():
    for pq_file, xl_file in zip(PARQUET_FILES, EXCEL_FILES):
        df = pd.read_parquet(pq_file)
        df["datetime"] = df["datetime"].dt.tz_localize(None)
        print(f"📊 {pq_file}: shape={df.shape}, columns={list(df.columns)}")
        print(f"   energy stats: mean={df['energy'].mean():.2f}, std={df['energy'].std():.2f}, min={df['energy'].min():.2f}, max={df['energy'].max():.2f}")
        df.to_excel(xl_file, index=False)
        print(f"✅ Saved {xl_file} with shape {df.shape} and {len(df)} rows")

def load_holidays(path):
    holidays_df = pd.read_excel(path)
    holidays_df['DateKEY'] = pd.to_datetime(holidays_df['DateKEY'], format='%Y%m%d')
    print(f"📅 Holidays: shape={holidays_df.shape}, sample_dates={holidays_df['DateKEY'].head().tolist()}")
    return holidays_df

def standardize_and_save(df_train, df_val, df_test, holidays_df):
    print("🔍 Applying feature engineering...")
    df_train = create_enhanced_features(df_train, holidays_df)
    df_val = create_enhanced_features(df_val, holidays_df)
    df_test = create_enhanced_features(df_test, holidays_df)
    
    print(f"📊 Train after features: shape={df_train.shape}, is_holiday_count={df_train['is_holiday'].sum()}")
    print(f"   Train energy stats: mean={df_train['energy'].mean():.2f}, std={df_train['energy'].std():.2f}")
    print(f"📊 Val after features: shape={df_val.shape}, is_holiday_count={df_val['is_holiday'].sum()}")
    print(f"📊 Test after features: shape={df_test.shape}, is_holiday_count={df_test['is_holiday'].sum()}")
    
    df_train_scaled, df_val_scaled, df_test_scaled, scaler = standardize_features(
        df_train, df_val, df_test, SELECTED_FEATURES
    )
    
    print(f"📊 Train scaled: shape={df_train_scaled.shape}, sample={df_train_scaled[SELECTED_FEATURES].head(2)}")
    print(f"📊 Val scaled: shape={df_val_scaled.shape}")
    print(f"📊 Test scaled: shape={df_test_scaled.shape}")

    for df_scaled, orig_df, name in zip(
        [df_train_scaled, df_val_scaled, df_test_scaled],
        [df_train, df_val, df_test],
        ["X_train_scaled.xlsx", "X_val_scaled.xlsx", "X_test_scaled.xlsx"]
    ):
        df_scaled.insert(0, 'datetime', orig_df['datetime'].values)
        df_scaled.insert(1, 'energy', orig_df['energy'].values)
        df_scaled.to_excel(name, index=False)
        print(f"✅ Saved {name} with shape {df_scaled.shape}")

def run_preprocessing():
    load_and_save_excel()
    holidays_df = load_holidays(HOLIDAY_FILE)
    df_train = pd.read_excel(EXCEL_FILES[2])
    df_val = pd.read_excel(EXCEL_FILES[1])
    df_test = pd.read_excel(EXCEL_FILES[0])
    print(f"📊 Loaded train: shape={df_train.shape}, val: shape={df_val.shape}, test: shape={df_test.shape}")
    standardize_and_save(df_train, df_val, df_test, holidays_df)

if __name__ == "__main__":
    run_preprocessing()
