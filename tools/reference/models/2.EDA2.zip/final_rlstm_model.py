# final_rlstm_model.py
import os
import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers, Input, callbacks
import tensorflow_probability as tfp
import gc
from data_utils import create_sliding_windows, create_tf_dataset

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.chdir(os.path.dirname(os.path.abspath(__file__)))

# Configuration
input_window = 168
output_window = 168
batch_size = 32
random_seed = 42
lambda_reg = 0.0002
selected_features = [
    'air_temperature', 'diffuse_r', 'elspot', 'full_solar', 'global_r',
    'gust_speed', 'relative_humidity', 'sunshine', 'wind_speed',
    'hour', 'weekday', 'is_weekend', 'is_holiday', 'is_long_holiday',
    'avg_temperature', 'temp_lag1', 'is_peak_hour'
]

# Load Data
df_Train = pd.read_excel("X_train_scaled.xlsx")
df_Val = pd.read_excel("X_val_scaled.xlsx")
X_train_full = df_Train[selected_features].to_numpy()
X_val_full = df_Val[selected_features].to_numpy()
y_train_full = df_Train['energy'].to_numpy().reshape(-1, 1).astype(np.float32)
y_val_full = df_Val['energy'].to_numpy().reshape(-1, 1).astype(np.float32)

X_train, y_train = create_sliding_windows(X_train_full, y_train_full, input_window, output_window)
X_val, y_val = create_sliding_windows(X_val_full, y_val_full, input_window, output_window)

X_train = X_train.reshape((-1, input_window, len(selected_features)))
X_val = X_val.reshape((-1, input_window, len(selected_features)))
y_train = y_train.reshape((-1, output_window))
y_val = y_val.reshape((-1, output_window))

train_dataset = create_tf_dataset(X_train, y_train, batch_size)
val_dataset = create_tf_dataset(X_val, y_val, batch_size)

# Hybrid Loss Function
@tf.function
def hybrid_loss(y_true, y_pred, alpha=0.2):
    mu = y_pred[:, :, 0]
    log_var = y_pred[:, :, 1]
    var = tf.nn.softplus(log_var) + 1e-6
    nll = tf.reduce_mean(0.5 * (tf.math.log(var) + tf.square(y_true - mu) / var))
    mse = tf.reduce_mean(tf.square(y_true - mu))
    peak_mask = y_true > tfp.stats.percentile(y_true, 80.0, axis=-1, keepdims=True)
    mse_peak = tf.where(peak_mask, tf.square(y_true - mu) * 1.5, tf.square(y_true - mu))
    reg = lambda_reg * tf.reduce_mean(log_var ** 2)
    return alpha * nll + (1 - alpha) * tf.reduce_mean(mse_peak) + reg

# Model Builder
def build_rlstm_model(lstm_units, dropout_rate, learning_rate, seed_offset, input_shape, output_window=168):
    tf.random.set_seed(random_seed + seed_offset)
    inputs = Input(shape=input_shape)
    x = layers.LSTM(lstm_units, return_sequences=True, dropout=dropout_rate,
                    kernel_initializer=tf.keras.initializers.GlorotNormal(seed=seed_offset))(inputs)
    x = layers.BatchNormalization()(x)
    x = layers.LSTM(lstm_units // 2, return_sequences=True, dropout=dropout_rate,
                    kernel_initializer=tf.keras.initializers.GlorotNormal(seed=seed_offset+1))(x)
    x = layers.LSTM(lstm_units // 4, return_sequences=False, dropout=dropout_rate,
                    kernel_initializer=tf.keras.initializers.GlorotNormal(seed=seed_offset+2))(x)
    x_residual = layers.Dense(lstm_units // 4, activation='relu')(x)
    x = layers.RepeatVector(output_window)(x + x_residual)
    x = layers.LSTM(lstm_units // 2, return_sequences=True, dropout=dropout_rate,
                    kernel_initializer=tf.keras.initializers.GlorotNormal(seed=seed_offset+3))(x)
    x = layers.LSTM(lstm_units // 4, return_sequences=True, dropout=dropout_rate,
                    kernel_initializer=tf.keras.initializers.GlorotNormal(seed=seed_offset+4))(x)
    x = layers.TimeDistributed(layers.Dense(lstm_units // 4, activation='relu',
                     kernel_initializer=tf.keras.initializers.GlorotNormal(seed=seed_offset+5)))(x)
    outputs = layers.TimeDistributed(layers.Dense(2, kernel_initializer=tf.keras.initializers.GlorotNormal(seed=seed_offset+6),
                          bias_initializer=tf.keras.initializers.Constant(value=[0.0, -3.0])))(x)
    model = models.Model(inputs, outputs)
    model.compile(optimizer=optimizers.Adam(learning_rate),
                  loss=lambda y_true, y_pred: hybrid_loss(y_true, y_pred))
    return model

# Load Best Parameters
with open("best_params.txt", "r") as f:
    best_params = eval(f.read())  # Safely evaluate the string to dict

# Train Best Model
print("🔹 Training Best Model")
best_model = build_rlstm_model(
    lstm_units=best_params['lstm_units'],
    dropout_rate=best_params['dropout_rate'],
    learning_rate=best_params['learning_rate'],
    seed_offset=best_params['seed_offset'],
    input_shape=(input_window, len(selected_features)),
    output_window=output_window
)

best_model.fit(
    train_dataset,
    validation_data=val_dataset,
    epochs=200,
    callbacks=[
        callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=15, min_lr=1e-6),
        callbacks.EarlyStopping(monitor='val_loss', patience=30, restore_best_weights=True, min_delta=0.001),
        callbacks.ModelCheckpoint('best_model.h5', monitor='val_loss', save_best_only=True, mode='min')
    ],
    verbose=2
)

# Load Top 5 Trials
with open("top_trials_params.txt", "r") as f:
    top_trials_params = eval(f.read())

# Train Ensemble of Top 5 Models
print("🔹 Training Top 5 Ensemble Models")
for i, params in enumerate(top_trials_params):
    print(f"🔸 Training Model {i+1} with seed_offset={params['seed_offset'] + i * 10}")
    model = build_rlstm_model(
        lstm_units=params['lstm_units'],
        dropout_rate=params['dropout_rate'],
        learning_rate=params['learning_rate'],
        seed_offset=params['seed_offset'] + i * 10,
        input_shape=(input_window, len(selected_features)),
        output_window=output_window
    )
    model.fit(
        train_dataset,
        validation_data=val_dataset,
        epochs=200,
        callbacks=[
            callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=15, min_lr=1e-6),
            callbacks.EarlyStopping(monitor='val_loss', patience=30, restore_best_weights=True, min_delta=0.001),
            callbacks.ModelCheckpoint(f'top_model_{i+1}.h5', monitor='val_loss', save_best_only=True, mode='min')
        ],
        verbose=2
    )
    tf.keras.backend.clear_session()
    gc.collect()

print("✅ All models trained and saved.")
