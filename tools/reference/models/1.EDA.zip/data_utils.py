# data_utils.py
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.chdir(os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

# --- Sliding Window Function ---
def create_sliding_windows(X_full, y_full, input_window, output_window):
    X, y = [], []
    for i in range(len(X_full) - input_window - output_window + 1):
        X.append(X_full[i:i + input_window])
        y.append(y_full[i + input_window:i + input_window + output_window].flatten())
    return np.array(X), np.array(y)

# --- TF Dataset Creator ---
def create_tf_dataset(X, y, batch_size=32):
    import tensorflow as tf
    dataset = tf.data.Dataset.from_tensor_slices((X, y))
    return dataset.shuffle(buffer_size=10000).batch(batch_size).prefetch(tf.data.AUTOTUNE)

# --- Feature Engineering ---
def create_enhanced_features(df, holidays_df):
    df['datetime'] = pd.to_datetime(df['datetime'])
    df['hour'] = df['datetime'].dt.hour
    df['weekday'] = df['datetime'].dt.weekday
    df['is_weekend'] = df['weekday'].isin([5, 6]).astype(int)
    df['is_holiday'] = df['datetime'].dt.date.isin(holidays_df['DateKEY'].dt.date).astype(int)
    df['is_long_holiday'] = df['is_holiday'].rolling(window=7).sum().ffill()
    df['avg_temperature'] = df['air_temperature'].rolling(window=7).mean().bfill()
    df['temp_lag1'] = df['air_temperature'].shift(1).bfill()
    df['is_peak_hour'] = df['hour'].isin([8, 9, 17, 18]).astype(int)
    df.fillna(df.mean(numeric_only=True), inplace=True)
    return df

# --- Standardize Features ---
def standardize_features(df_train, df_val, df_test, selected_features):
    scaler = StandardScaler()
    df_train_scaled = pd.DataFrame(scaler.fit_transform(df_train[selected_features]),
                                   columns=selected_features)
    df_val_scaled = pd.DataFrame(scaler.transform(df_val[selected_features]),
                                 columns=selected_features)
    df_test_scaled = pd.DataFrame(scaler.transform(df_test[selected_features]),
                                  columns=selected_features)
    return df_train_scaled, df_val_scaled, df_test_scaled, scaler
